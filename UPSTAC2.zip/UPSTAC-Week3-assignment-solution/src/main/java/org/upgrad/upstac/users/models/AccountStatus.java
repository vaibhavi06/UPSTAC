package org.upgrad.upstac.users.models;

public enum AccountStatus {
    INITIATED,APPROVED,REJECTED,DELETED
}
